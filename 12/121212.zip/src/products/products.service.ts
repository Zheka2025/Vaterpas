import { Injectable, Logger } from '@nestjs/common';
import { InjectRepository } from '@nestjs/typeorm';
import { Repository } from 'typeorm';
import { Product } from './product.entity';

@Injectable()
export class ProductsService {
  private readonly logger = new Logger(ProductsService.name);

  constructor(
    @InjectRepository(Product)
    private readonly productRepo: Repository<Product>,
  ) {}

  async findAll() {
    this.logger.log('Fetching all products');
    return this.productRepo.find({
      relations: ['category', 'brand'],
    });
  }

  async findOne(id: number) {
    this.logger.log(`Fetching product with id: ${id}`);
    return this.productRepo.findOne({
      where: { id },
      relations: ['category', 'brand'],
    });
  }

  async findByUuid(uuid: string) {
    this.logger.log(`Fetching product with uuid: ${uuid}`);
    return this.productRepo.findOne({
      where: { uuid },
      relations: ['category', 'brand'],
    });
  }

  async findByCategory(categoryId: number) {
    this.logger.log(`Fetching products for category: ${categoryId}`);
    return this.productRepo.find({
      where: { category: { id: categoryId } },
      relations: ['category', 'brand'],
    });
  }

  async findNewArrivals() {
    this.logger.log('Fetching new arrivals');
    return this.productRepo.find({
      where: { isNew: true },
      relations: ['category', 'brand'],
    });
  }

  async create(productData: Partial<Product>) {
    this.logger.log('Creating new product');
    const product = this.productRepo.create(productData);
    return this.productRepo.save(product);
  }

  async update(id: number, productData: Partial<Product>) {
    this.logger.log(`Updating product with id: ${id}`);
    await this.productRepo.update(id, productData);
    return this.findOne(id);
  }

  async remove(id: number) {
    this.logger.log(`Removing product with id: ${id}`);
    return this.productRepo.delete(id);
  }
}
